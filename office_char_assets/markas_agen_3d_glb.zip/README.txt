MARKAS AGEN: Procedural GLB 3D Prototype Models

Eight independent glTF 2.0 binary models. Each file contains true 3D meshes with PBR materials.
Embedded simple keyframe animation clips: Idle, Walk, Wave, Sit, Typing, Coffee.

These models are procedural reconstructions of the provided 2D concept art, not exact image-to-mesh conversions.
Intended as first working 3D prototypes. No furniture or monitor is included in any character.
Rig: named moving object nodes, NOT skin-weight humanoid rigs. No IK/foot locking.
For production-grade rigging and walk cycles, refine in Blender.

Coordinate system: +Y up, +Z character face/front, feet near Y=0.
All models are static-position assets; apply movement via the Vue 3 Three.js scene.
